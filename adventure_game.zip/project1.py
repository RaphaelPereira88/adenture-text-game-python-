import time
import random


def print_pause(message):
    print(message)
    time.sleep(2)


def tell_name():
    global player
    player = input("player please enter you name:\n")


def intro():
    print_pause(player + " you are a night in a mission to help a village,\n")
    print_pause("your braviour has no equal and your name"
                " is wellknown in the 4 lands of Abraxion")
    print_pause("You find yourself standing in an open field,"
                " filled with grass and yellow wildflowers.")
    print_pause(f"Rumor has it that a {noun} is somewhere around here,"
                "and has been terrifying the nearby village.\n")
    print_pause("In front of you is a house.")
    print_pause("To your right is a dark cave.")
    print_pause("In your hand you hold your trusty"
                "(but not very effective) dagger.\n")


def cave(list):
    global weapon
    steel = ["sword of Ogoroth", "ax of Torix"]
    weapon = random.choice(steel)
    if "ax of Torix" in list and "sword of Ogoroth" in list:
        print_pause("You've been here before, and gotten"
                    " all the good stuff.\n"
                    "It's just an empty cave now."
                    "You walk back out to the field.\n")
        move(list)
    elif "ax of Torix" in list:
        print_pause("you've been there already " + player +
                    ", but you didn't really look deep into the cave")
        print_pause("this time, really deep into the cave"
                    " and you find a sword embedded in a rock")
        print_pause("you pull it and find out that it"
                    "is the sword of Ogoroth!\n")
        print_pause(player + " time to see if this new weapon "
                    "is worth its legend")
        print_pause("you leave the cave and head back to the field\n")
        list.append("sword of Ogoroth")
        move(list)
    elif "sword of Ogoroth" in list:
        print_pause("you've been there before but you"
                    " didn't really look deep into the cave")
        print_pause("this time, hidden in an old wooden "
                    "and dusty box you find a new weapon")
        print_pause("The ax of Torix !")
        print_pause("time to see if this weapon is worth its legend")
        print_pause("you leave the cave and head back to the field\n")
        list.append("ax of Torix")
        move(list)
    else:
        print_pause(player + " be careful you enter now in the cave.")
        print_pause("It turns out to be only a very small cave.")
        print_pause("Your eye catches a glint of metal behind a rock.")
        print_pause(player + " you found the magical " + weapon + "\n"
                    "that could increase by 10 times the power of your blows!")
        print_pause("You discard your silly old dagger"
                    " and take " + weapon + " with you.")
        print_pause("You walk back out to the field\n")
        list.append(weapon)
        move(list)


def wrong_input():
    print_pause("I don't understand your answer, please press 1 or 2")


def house(list):
    print_pause("You approach the door of the house.")
    print_pause("You are about to knock when the "
                f"door opens and out steps a {noun}")
    print_pause(f"Eep! This is the {noun}'s house!")
    print_pause(f"The {noun} attacks you!")
    if "sword of Ogoroth"not in list and "ax of Torix" not in list:
        print_pause("You feel a bit under-prepared for this"
                    ", what with only having a tiny dagger.")


def scenario_golum(list):
    print_pause(f"As {noun} moves to attack, you unsheath"
                " your new magnificent weapon")
    print_pause("The golum hits you severals time but you"
                " manage to dodge all of his attacks.")
    print_pause("time for you " + player + " to unleash"
                " the power of your weapons")
    response4 = input("Enter 1 to counter attack,"
                      " or Enter 2 to run away?\n")
    if '1' in response4:
        if "ax of Torix" in list:
            print_pause("you feel the power through your veins and"
                        " launch the attack\n"
                        "In one single blow you cut his head!"
                        "well done!" + player + " are victorious!")
            play_again()
        elif "sword of Ogoroth" in list:
            print_pause("you start attacking with an extraordinary"
                        " speed but your blows"
                        " don't seem to really damage the Golum")
            print_pause(player + " it might be wiser to retreat"
                        " and look for another weapon"
                        " may be a bit more effective on this enemy")
            response5 = input("Enter 1 to keep fighting , enter"
                              " 2 to retreat for now:\n")
            if "1" in response5:
                print_pause("you keep hitting with all your strengh"
                            " but the Golum hits back and kill you")
                print_pause("You 've been defeated!")
                play_again()
            elif '2' in response5:
                print_pause("you heading to the cave to hide and"
                            " think about how to defeat this bloody Golum")
                cave(list)
            else:
                wrong_input()
                scenario_golum(list)
        else:
            print_pause("You do your best...")
            print_pause(f"but your dagger is no match for the {noun}.")
            print_pause("You have been defeated!")
            play_again()
    elif '2' in response4:
        print_pause("you heading to the cave to hide and"
                    " think about how to defeat this bloody Golum")
        cave(list)
    else:
        wrong_input()
        scenario_golum(list)


def scenario_dragon(list):
    print_pause("the dragon start spiting fire at you,\n"
                "you manage to dodge it and all of"
                " a sudden your " + weapon + "\n"
                "starts shining even stronger and you"
                " feel his power trough your veins")
    response3 = input("Enter 1 to release this new power"
                      " in 1 blow, or Enter 2 to run away?")
    if '1' in response3:
        print_pause("you feel the power through your"
                    " veins and launch the attack.")
        print_pause("in one blow you cut his head welldone,"
                    + player + " you are victorious!")
        play_again()
    elif '2' in response3:
        cave(list)
    else:
        wrong_input()
        scenario_dragon(list)


def action(list):
    response2 = input("Would you like to (1) fight or (2) run away?\n")
    if '1' in response2:
        if "ax of Torix" in list or "sword of Ogoroth" in list:
            if noun == "dragon":
                scenario_dragon(list)
            elif noun == "golum":
                scenario_golum(list)
            else:
                print_pause(f"As {noun} moves to attack, you unsheath"
                            " your new magnificent weapon")
                print_pause(weapon + " shines brightly in your hand"
                            " as you brace yourself for the attack.")
                print_pause(f"{noun} takes one look at your"
                            " shiny new toy and runs away!")
                print_pause(f"You have rid the town of the {noun}.\n"
                            "You are victorious!")
                play_again()
        else:
            print_pause("You do your best...")
            print_pause(f"but your dagger is no match for the {noun}.")
            print_pause("You have been defeated!")
            play_again()
    elif '2' in response2:
        print_pause("You run back into the field. Luckily"
                    ", you don't seem to have been followed.")
        move(list)
    else:
        print_pause("I don't understand your answer, please press 1 or 2")
        action(list)


def move(list):
    print_pause("Enter 1 to knock on the door of the house ")
    print_pause("Enter 2 to peer into the cave.\n")
    response1 = input("What would you like to do?\n"
                      "(Please enter 1 or 2.)\n")
    if '1' in response1:
        house(list)
        action(list)
    elif '2' in response1:
        cave(list)
    else:
        move(list)


def play_again():
    final_answer = input("Would you like to play again? (y/n)\n").lower()
    if "y" in final_answer.lower():
        print_pause("Excellent! Restarting the game ...")
        time.sleep(2)
        list = []
        global noun
        beast = ["Dragon", "pirate", "golum"]
        noun = random.choice(beast)
        intro()
        move(list)
    elif "n" in final_answer.lower():
        print("Let's play again whenever you want, see you soon! Thanks")

    else:
        print("sorry,I didn't understand you answer")
        play_again()


def game():
    list = []
    global noun
    beast = [ "Dragon", "pirate", "golum"]
    noun = random.choice(beast)
    tell_name()
    intro()
    move(list)


game()
